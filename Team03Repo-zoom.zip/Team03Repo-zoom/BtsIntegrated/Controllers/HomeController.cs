﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.WebPages;
using System.Xml.Linq;

namespace BtsIntegrated.Controllers
{
    public class HomeController : Controller
    {
        Manager m = new Manager();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [HttpPost]
        public ActionResult Markers(string postalCode, double zoom/*, double lat, double lng, bool check*/)
        {
            if (postalCode.IsEmpty()/* && !check*/)
            {
                return View("Index");
            }
            //if (postalCode.IsEmpty())
            //{
            //    var userGeoCoord = new UserGeoWithLocations
            //    {
            //        Latitude = lat,
            //        Longitude = lng,
            //        zoomsize = zoom,
            //        Locations = m.LocationGetAll()

            //    };
            //    return View(userGeoCoord);
            //}
        
            //else
            //{
                double[] data = new double[2];
            //    if (!check)
            //    {
                    data = m.GetUserLatLngCoords(postalCode);

                //}
                //else
                //{
                //    data[0] = lat;
                //    data[1] = lng;
                //}
                var userGeoCoord = new UserGeoWithLocations
                {
                    Latitude = data[0],
                    Longitude = data[1],
                    zoomsize = zoom,
                    Locations = m.LocationGetAll()

                };
                return View(userGeoCoord);
            //}
        }
    }
}