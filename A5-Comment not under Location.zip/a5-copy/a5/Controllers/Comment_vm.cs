﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace a5.Controllers
{
    public class CommentBase
    {
        public CommentBase()
        {

        }
        [Key]
        public int CommentId { get; set; }
        [StringLength(250)]
        public string Comments { get; set; }
    }
}