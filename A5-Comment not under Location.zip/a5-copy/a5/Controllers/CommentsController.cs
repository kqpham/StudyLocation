﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace a5.Controllers
{
    public class CommentsController : Controller
    {
        // GET: Comments
        private List<CommentBase> Comments;
        public CommentsController()
        {
            Comments = new List<CommentBase>();
            var firstC = new CommentBase();
            firstC.CommentId = 1;
            firstC.Comments = "First Comment";
            Comments.Add(firstC);
        }
        public ActionResult Index()
        {
            return View(Comments);
        }

        // GET: Comments/Details/5
        public ActionResult Details(int id)
        {
            return View(Comments[id-1]);
        }

        // GET: Comments/Create
        public ActionResult Create()
        {
            return View(new CommentBase());
        }

        // POST: Comments/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Comments/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Comments/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Comments/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Comments/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
