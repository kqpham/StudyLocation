﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace a5.Controllers
{
    public class Location
    {
    }
}