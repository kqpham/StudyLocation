﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace a5.Models
{
    public class Location
    {
        [Key]
        public int LocationID { get; set; }

        [Display(Name = "Address")]
        public string Address { get; set; }

        [DataType(DataType.PostalCode)]
        public string PostalCode { get; set; }

        [Phone]
        [DataType(DataType.PhoneNumber)]
        public string PhoneNumber { get; set; }

        public string City { get; set; }

        public bool WifiAvailability { get; set; }

        public bool Outlet { get; set; }

        public bool StudyRoom { get; set; }

        public bool Printers { get; set; }

        public bool Purchase { get; set; }

        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

        public bool Food { get; set; }

        public bool Washrooms { get; set; }

        public bool HandicapAccess { get; set; }

        public bool AcceptDebit { get; set; }

        public bool AcceptCredit { get; set; }

        public bool CashOnly { get; set; }

        [DataType(DataType.Url)]
        public string Website { get; set; }

        //public virtual ICollection <Day> Days { get; set; }

        [Display(Name = "Monday")]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? MondayOpeningTime { get; set; }

        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? MondayClosingTime { get; set; }

        [Display(Name = "Tuesday")]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? TuesdayOpeningTime { get; set; }

        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? TuesdayClosingTime { get; set; }

        [Display(Name = "Wednesday")]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? WednesdayOpeningTime { get; set; }

        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? WednesdayClosingTime { get; set; }

        [Display(Name = "Thursday")]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? ThursdayOpeningTime { get; set; }

        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? ThursdayClosingTime { get; set; }

        [Display(Name = "Friday")]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? FridayOpeningTime { get; set; }

        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? FridayClosingTime { get; set; }

        [Display(Name = "Saturday")]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? SaturdayOpeningTime { get; set; }

        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? SaturdayClosingTime { get; set; }

        [Display(Name = "Sunday")]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? SundayOpeningTime { get; set; }

        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM tt}", ApplyFormatInEditMode = true)]
        public DateTime? SundayClosingTime { get; set; }
    }
}