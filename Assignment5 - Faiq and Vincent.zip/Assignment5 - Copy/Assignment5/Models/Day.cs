﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment5.Models
{
    public class Day
    {
        public int DayID { get; set; }

        public Timings DayTimings { get; set; }

        public virtual Location Location { get; set; }
        public virtual Timings Timings { get; set; }

    }
}