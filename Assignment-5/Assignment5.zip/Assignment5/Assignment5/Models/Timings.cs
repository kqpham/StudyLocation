﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Assignment5.Models
{
    public class Timings
    {
        public int TimingsID { get; set; }

        [Display(Name = "Opening Time")]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM A}", ApplyFormatInEditMode = true)]
        public DateTime OpeningTime { get; set; }

        [Display(Name = "Closing Time")]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0: HH:MM A}", ApplyFormatInEditMode = true)]
        public DateTime ClosingTime { get; set; }

        public virtual ICollection<Day> Days { get; set; }
    }
}