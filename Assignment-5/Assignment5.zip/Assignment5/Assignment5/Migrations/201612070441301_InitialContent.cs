namespace Assignment5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialContent : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Location", "MondayOpeningTime", c => c.DateTime());
            AlterColumn("dbo.Location", "MondayClosingTime", c => c.DateTime());
            AlterColumn("dbo.Location", "TuesdayOpeningTime", c => c.DateTime());
            AlterColumn("dbo.Location", "TuesdayClosingTime", c => c.DateTime());
            AlterColumn("dbo.Location", "WednesdayOpeningTime", c => c.DateTime());
            AlterColumn("dbo.Location", "WednesdayClosingTime", c => c.DateTime());
            AlterColumn("dbo.Location", "ThursdayOpeningTime", c => c.DateTime());
            AlterColumn("dbo.Location", "ThursdayClosingTime", c => c.DateTime());
            AlterColumn("dbo.Location", "FridayOpeningTime", c => c.DateTime());
            AlterColumn("dbo.Location", "FridayClosingTime", c => c.DateTime());
            AlterColumn("dbo.Location", "SaturdayOpeningTime", c => c.DateTime());
            AlterColumn("dbo.Location", "SaturdayClosingTime", c => c.DateTime());
            AlterColumn("dbo.Location", "SundayOpeningTime", c => c.DateTime());
            AlterColumn("dbo.Location", "SundayClosingTime", c => c.DateTime());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Location", "SundayClosingTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "SundayOpeningTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "SaturdayClosingTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "SaturdayOpeningTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "FridayClosingTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "FridayOpeningTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "ThursdayClosingTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "ThursdayOpeningTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "WednesdayClosingTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "WednesdayOpeningTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "TuesdayClosingTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "TuesdayOpeningTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "MondayClosingTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Location", "MondayOpeningTime", c => c.DateTime(nullable: false));
        }
    }
}
