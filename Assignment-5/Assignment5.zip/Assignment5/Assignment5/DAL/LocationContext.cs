﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;
using Assignment5.Models;

namespace Assignment5.DAL
{
    public class LocationContext:DbContext
    {
        public LocationContext (): base ("LocationContext")
        {
            
        }

        public DbSet<Location> Locations { get; set; }
        public DbSet<Day> Days { get; set; }
        public DbSet<Timings> Timings { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Location>().ToTable("Location");
            modelBuilder.Entity<Day>().ToTable("Day");
            modelBuilder.Entity<Timings>().ToTable("Timings");
        }

    }
}