﻿namespace Assignment_5_BTS.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using System.Web;
    using System.Data.Entity;
    public partial class DataContext :DbContext
    {
        public DataContext()
               : base("name=DataContext")
        {
        }
        public virtual DbSet<Comment> Comments { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Comment>();
        }
    }
}