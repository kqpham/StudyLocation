﻿

namespace Assignment_5_BTS.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using System.Web;

    [Table("Comment")]
    public partial class Comment
    {
        [Key]
        public int CommentId { get; set; }

        [StringLength(250)]
        public string Comments { get; set; }
    }
}