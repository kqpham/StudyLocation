﻿
namespace Assignment_5_BTS.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using AutoMapper;
    using Assignment_5_BTS.Models;
    public class Manager
    {
        private DataContext ds = new DataContext();
        public Manager()
        {

        }
        public IEnumerable<CommentBase> CommentGetAll()
        {
            var results = new List<CommentBase>();

            var allComments = ds.Comments;

            foreach(var comments in allComments)
            {
                var e = new CommentBase();
                e.Comments = comments.Comments;

                results.Add(e);
            }
            return results;
        }
        public CommentBase CommentGetById(int id)
        {
            var f = ds.Comments.Find(id);

            return (f == null) ? null : Mapper.Map<CommentBase>(f);
        }
        public CommentBase CommentAdd(CommentAdd newItem)
        {
            var addedItem = ds.Comments.Add(Mapper.Map<Comment>(newItem));
            ds.SaveChanges();

            return (addedItem == null) ? null : Mapper.Map<CommentBase>(addedItem);
        }
    }
}