﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;

namespace Assignment_5_BTS
{
    public static class AutoMapperConfig
    {
        public static void RegisterMappings()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Models.Comment, Controllers.CommentBase>();
                cfg.CreateMap<Controllers.CommentAdd, Models.Comment>();
            });
            //Mapper.CreateMap<Models.Comment, Controllers.CommentBase>();
            //Mapper.CreateMap<Controllers.CommentAdd, Models.Comment>();
        }
    }
}