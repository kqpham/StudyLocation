﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Assignment_5.Controllers
{
    public class RatingsController : Controller
    {
        private List<RatingBase> Ratings;
        public RatingsController()
        {
            Ratings = new List<RatingBase>();
            var r1 = new RatingBase();
            r1.Id = 1;
            r1.Customer = "Kevin";
            r1.Score = 5;
            Ratings.Add(r1);

            var r2 = new RatingBase();
            r2.Id = 2;
            r2.Customer = "Faiq";
            r2.Score = 4;
            Ratings.Add(r2);

            var r3 = new RatingBase();
            r3.Id = 3;
            r3.Customer = "Vincent";
            r3.Score = 5;
            Ratings.Add(r3);

            var r4 = new RatingBase();
            r4.Id = 4;
            r4.Customer = "Iceal";
            r4.Score = 3;
            Ratings.Add(r4);
        }
        // GET: Ratings
        public ActionResult Index()
        {

            return View(Ratings);
        }

        // GET: Ratings/Details/5
        public ActionResult Details(int id)
        {

            return View(Ratings[id-1]);
        }

        // GET: Ratings/Create
        public ActionResult Create()
        {

            return View(new RatingBase());
        }

        // POST: Ratings/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            var newRating = new RatingBase();
            try
            {
                //configure unique identifier
                newRating.Id = Ratings.Count + 1;

                //configure string properties
                newRating.Customer = collection["Customer"];

                //configure numbers; enter mthod as strings
                int score;
                bool isNumber;

                isNumber = Int32.TryParse(collection["Score"], out score);
                newRating.Score = score;

                //Add to collection
                Ratings.Add(newRating);

                //Show results using existing Details view
                return View("Details", newRating);
            }
            catch
            {
                return View();
            }
        }

        // GET: Ratings/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Ratings/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Ratings/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Ratings/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
